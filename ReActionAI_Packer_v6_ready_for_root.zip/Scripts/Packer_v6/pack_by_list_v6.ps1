# ReActionAI Archiver v6 — packs project into ReActionAI_latest.zip
# Encoding: UTF-8 (no BOM)
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'ReActionAI Archiver v6'

Write-Host ("="*48)
Write-Host "   ReActionAI Archiver v6"
Write-Host ("="*48)

# Resolve script folder and request file
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RequestFile = Join-Path $ScriptDir 'ReActionAI_request.txt'

if (-not (Test-Path $RequestFile)) {
    throw "[ERROR] Request file not found at $RequestFile"
}

# Parse request file (KEY: VALUE)
$archiveRoot = $null
$uploadRoot  = $null

Get-Content -Path $RequestFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -match '^\s*#') { return }
    if ($line -match '^\s*$') { return }
    if ($line -match '^\s*([^:]+)\s*:\s*(.+)\s*$') {
        $key = $matches[1].Trim().ToUpperInvariant()
        $val = $matches[2].Trim()
        switch ($key) {
            'ARCHIVE'   { $archiveRoot = $val }
            'UPLOAD_TO' { $uploadRoot  = $val }
        }
    }
}

if (-not $archiveRoot) { throw "[ERROR] ARCHIVE path not provided in $RequestFile" }
if (-not $uploadRoot)  { throw "[ERROR] UPLOAD_TO path not provided in $RequestFile" }

# Normalize paths
$archiveRoot = (Resolve-Path -LiteralPath $archiveRoot).Path
if (-not (Test-Path -LiteralPath $uploadRoot)) {
    New-Item -ItemType Directory -Path $uploadRoot | Out-Null
}
$uploadRoot = (Resolve-Path -LiteralPath $uploadRoot).Path

Write-Host "[INFO] Source path: $archiveRoot"
Write-Host "[INFO] Upload path: $uploadRoot"

# Output file name (fixed)
$zipName = "ReActionAI_latest.zip"
$zipPath = Join-Path $uploadRoot $zipName

# Remove existing archive if present
if (Test-Path -LiteralPath $zipPath) {
    try {
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction Stop
        Write-Host "[INFO] Previous archive removed."
    } catch {
        throw "[ERROR] Can't remove existing archive: $zipPath. Details: $($_.Exception.Message)"
    }
}

# Use .NET Zip API to include files and exclude junk reliably
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
$base = (Resolve-Path $archiveRoot).Path

$excludeRegex = @(
    '\\\.git(\\|$)',
    '\\\.vs(\\|$)',
    '\\bin(\\|$)',
    '\\obj(\\|$)',
    '\\archives(\\|$)',
    '\\logs(\\|$)'
)

function Should-Exclude($fullPath) {
    foreach ($rx in $excludeRegex) {
        if ($fullPath -imatch $rx) { return $true }
    }
    $name = [System.IO.Path]::GetFileName($fullPath)
    if ($name -like '*.user') { return $true }
    if ($name -like '*.suo')  { return $true }
    if ($name -like '*.zip')  { return $true }
    return $false
}

Get-ChildItem -LiteralPath $archiveRoot -Recurse -Force -File | ForEach-Object {
    if (Should-Exclude $_.FullName) { return }
    $rel = $_.FullName.Substring($base.Length).TrimStart('\','/')
    $rel = $rel -replace '\\','/'
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip, $_.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal
    ) | Out-Null
}

$zip.Dispose()
Write-Host "[OK] Archive created: $zipPath" -ForegroundColor Green
Write-Host "Press any key to exit ..."
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
