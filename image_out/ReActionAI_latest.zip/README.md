# ReActionAI

[![Build Status](https://github.com/Alex-Proven/ReActionAI/actions/workflows/ci.yml/badge.svg)](https://github.com/Alex-Proven/ReActionAI/actions)

> 🧠 *ReActionAI* — интеллектуальный плагин для Revit, объединяющий AI-личности, когнитивную базу знаний и автоматизацию BIM-процессов.

---
