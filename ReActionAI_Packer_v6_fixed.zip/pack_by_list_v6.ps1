# ReActionAI Archiver v6 — packs project into ReActionAI_latest.zip
# Encoding: UTF-8 (no BOM)

$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'ReActionAI Archiver v6'

Write-Host ("="*48)
Write-Host "   ReActionAI Archiver v6"
Write-Host ("="*48)

# --- Resolve script folder and request file ---
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RequestFile = Join-Path $ScriptDir 'ReActionAI_request.txt'

if (-not (Test-Path $RequestFile)) {
    throw "[ERROR] Request file not found at $RequestFile"
}

# --- Parse request file (KEY: VALUE) ---
$archiveRoot = $null
$uploadRoot  = $null

Get-Content -Path $RequestFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -match '^\s*#') { return }
    if ($line -match '^\s*$') { return }
    if ($line -match '^\s*([^:]+)\s*:\s*(.+)\s*$') {
        $key = $matches[1].Trim().ToUpperInvariant()
        $val = $matches[2].Trim()
        switch ($key) {
            'ARCHIVE'   { $archiveRoot = $val }
            'UPLOAD_TO' { $uploadRoot  = $val }
        }
    }
}

if (-not $archiveRoot) { throw "[ERROR] ARCHIVE path not provided in $RequestFile" }
if (-not $uploadRoot)  { throw "[ERROR] UPLOAD_TO path not provided in $RequestFile" }

# Normalize paths
$archiveRoot = (Resolve-Path -LiteralPath $archiveRoot).Path
if (-not (Test-Path -LiteralPath $uploadRoot)) {
    New-Item -ItemType Directory -Path $uploadRoot | Out-Null
}
$uploadRoot = (Resolve-Path -LiteralPath $uploadRoot).Path

Write-Host "[INFO] Source path: $archiveRoot"
Write-Host "[INFO] Upload path: $uploadRoot"

# --- Prepare output file name (no timestamp, always 'ReActionAI_latest.zip') ---
$zipName = "ReActionAI_latest.zip"
$zipPath = Join-Path $uploadRoot $zipName

# --- Remove existing 'latest' archive if present ---
if (Test-Path -LiteralPath $zipPath) {
    try {
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction Stop
    } catch {
        throw "[ERROR] Can't remove existing archive: $zipPath. Details: $($_.Exception.Message)"
    }
}

# --- Use Windows bsdtar (tar.exe) to create a zip with excludes ---
# This is more reliable for large trees than Compress-Archive and supports --exclude.
# We change working dir (-C) to the archive root and archive '.'
$tar = "tar.exe"
$excludeArgs = @(
    "--exclude=.git",
    "--exclude=.vs",
    "--exclude=bin",
    "--exclude=obj",
    "--exclude=archives",
    "--exclude=logs",
    "--exclude=*.zip",
    "--exclude=*.user",
    "--exclude=*.suo"
)

Write-Host "[INFO] Creating archive..."
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $tar
$psi.ArgumentList.AddRange(@("-a", "-c", "-f", $zipPath, "-C", $archiveRoot, "."))
$excludeArgs | ForEach-Object { $psi.ArgumentList.Add($_) }
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError  = $true
$psi.UseShellExecute = $false

$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $psi
$null = $proc.Start()
$stdout = $proc.StandardOutput.ReadToEnd()
$stderr = $proc.StandardError.ReadToEnd()
$proc.WaitForExit()

if ($proc.ExitCode -ne 0) {
    Write-Host $stdout
    Write-Host $stderr
    throw "[ERROR] tar.exe failed with exit code $($proc.ExitCode)"
}

if (-not (Test-Path -LiteralPath $zipPath)) {
    throw "[ERROR] Archive was not created: $zipPath"
}

Write-Host "[OK] Archive created: $zipPath" -ForegroundColor Green
Write-Host "Press any key to exit ..."
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')