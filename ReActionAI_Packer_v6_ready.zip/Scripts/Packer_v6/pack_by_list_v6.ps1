[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$requestFile = Join-Path $scriptDir 'ReActionAI_request.txt'

Write-Host "================================" 
Write-Host "   ReActionAI Archiver v6"
Write-Host "================================"

if (-not (Test-Path $requestFile)) {
    throw "[ERROR] Request file not found: $requestFile"
}

$req = @{}
Get-Content $requestFile | ForEach-Object {
    if ($_ -match '^\s*#') { return }
    if ($_ -match '^\s*$') { return }
    if ($_ -match '^\s*([^:]+)\s*:\s*(.+?)\s*$') {
        $req[$matches[1].Trim().ToUpper()] = $matches[2].Trim()
    }
}

$sourcePath = $req['ARCHIVE']
$uploadPath = $req['UPLOAD_TO']

if (-not $sourcePath) { throw "[ERROR] ARCHIVE path is not set in request file." }
if (-not $uploadPath) { throw "[ERROR] UPLOAD_TO path is not set in request file." }

if (-not (Test-Path $sourcePath)) { throw "[ERROR] Source path not found: $sourcePath" }
if (-not (Test-Path $uploadPath)) { New-Item -ItemType Directory -Path $uploadPath | Out-Null }

$zipName  = 'ReActionAI_latest.zip'
$zipPath  = Join-Path $uploadPath $zipName

Write-Host "[INFO] Source path: $sourcePath"
Write-Host "[INFO] Upload path: $uploadPath"
Write-Host "[INFO] Output name: $zipName"
Write-Host ""

if (Test-Path $zipPath) {
    try {
        Remove-Item -LiteralPath $zipPath -Force
        Write-Host "[INFO] Old archive removed: $zipPath"
    } catch {
        Write-Host "[WARN] Failed to remove old archive, will try overwrite..." -ForegroundColor Yellow
    }
}

$all = Get-ChildItem -LiteralPath $sourcePath -Recurse -Force
$files = $all | Where-Object {
    -not $_.PSIsContainer -and
    ($_.FullName -notmatch '\\\.git(\\|$)') -and
    ($_.FullName -notmatch '\\\.vs(\\|$)')  -and
    ($_.FullName -notmatch '\\bin(\\|$)')   -and
    ($_.FullName -notmatch '\\obj(\\|$)')   -and
    ($_.FullName -notmatch '\\archives(\\|$)') -and
    ($_.FullName -notmatch '\\logs(\\|$)')  -and
    ($_.Name -notlike '*.user') -and
    ($_.Name -notlike '*.suo')  -and
    ($_.Name -notlike '*.zip')
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
$base = (Resolve-Path $sourcePath).Path

foreach ($f in $files) {
    $rel = $f.FullName.Substring($base.Length).TrimStart('\','/')
    $rel = $rel -replace '\\','/'
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip, $f.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal
    ) | Out-Null
}
$zip.Dispose()

Write-Host "[OK] Archive created: $zipPath" -ForegroundColor Green
Read-Host "Для продолжения нажмите клавишу ВВОД..."
