using System.Windows;
using System.Windows.Controls;
using System.Threading.Tasks;

namespace ReActionAI.Modules.RevitChatGPT.UI
{
    public partial class ChatWindow : Window
    {
        private readonly Services.IChatClient _client;

        public ChatWindow()
        {
            InitializeComponent();
            _client = new Services.ChatClient();
        }

        private async void SendBtn_Click(object sender, RoutedEventArgs e)
        {
            var text = PromptBox.Text?.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;

            AppendBubble(text, isUser:true);
            PromptBox.Clear();

            var reply = await _client.SendAsync(text);
            AppendBubble(reply, isUser:false);
        }

        private void AppendBubble(string text, bool isUser)
        {
            var tb = new TextBlock { Text = (isUser ? "You: " : "AI: ") + text, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,4,0,4) };
            ChatStack.Children.Add(tb);
        }
    }
}
