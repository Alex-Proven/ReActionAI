
# FixPack_v5 (v2) — ReActionAI (Revit 2024)
param(
  [string]$Configuration = "Debug",
  [string]$Platform = "x64"
)
$ErrorActionPreference = "Stop"
Write-Host "`n== FixPack_v5_v2: start =="

$repo = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
if (-not (Test-Path (Join-Path $repo 'ReActionAI.sln'))) {
  throw "Solution 'ReActionAI.sln' not found at $repo."
}

$src       = Join-Path $repo 'src'
$projMod   = Join-Path $src 'Modules\RevitChatGPT'
$projAbs   = Join-Path $src 'Abstractions\ReActionAI.Abstractions'
$projCore  = Join-Path $src 'ReActionAI'
$projTests = Join-Path $repo 'tests\ReActionAI.Tests'

# Clean
foreach ($p in @($projMod,$projAbs,$projCore,$projTests)) {
  if ($p -and (Test-Path $p)) {
    foreach ($d in @('bin','obj')) {
      $path = Join-Path $p $d
      if (Test-Path $path) { Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "Cleaned: $path" }
    }
  }
}

# Build
$sln = Join-Path $repo 'ReActionAI.sln'
$msbuild = $null
foreach ($c in @(
  "msbuild.exe",
  "C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe",
  "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe",
  "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe"
)) { if (Get-Command $c -ErrorAction SilentlyContinue) { $msbuild = $c; break } }
if (-not $msbuild) { $msbuild = (Get-Command 'dotnet' -ErrorAction SilentlyContinue) }

if ($msbuild -and ($msbuild -like '*dotnet*')) {
  & $msbuild build $sln -c $Configuration -p:Platform=$Platform
} elseif ($msbuild) {
  & $msbuild $sln /t:Build /p:Configuration=$Configuration /p:Platform=$Platform
} else { throw "MSBuild/dotnet not found" }

# Find DLL
$outDir = Join-Path $projMod ("bin\{0}\{1}\net48" -f $Platform,$Configuration)
$dll = Join-Path $outDir 'ReActionAI.Modules.RevitChatGPT.dll'
if (-not (Test-Path $dll)) {
  $outDir = Join-Path $projMod ("bin\{0}\{1}" -f $Platform,$Configuration)
  $dll = Join-Path $outDir 'ReActionAI.Modules.RevitChatGPT.dll'
}
if (-not (Test-Path $dll)) { throw "Module DLL not found: $outDir" }

# Addins
$addinsRoot = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2024'
$pluginDir  = Join-Path $addinsRoot 'ReActionAI'
New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null

# Remove duplicates from root
$rootDll   = Join-Path $addinsRoot 'ReActionAI.Modules.RevitChatGPT.dll'
$rootAddin = Join-Path $addinsRoot 'ReActionAI.Modules.RevitChatGPT.addin'
foreach ($f in @($rootDll,$rootAddin)) {
  if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue; Write-Host "Removed root duplicate: $f" }
}

# Copy DLL into subfolder
$targetDll = Join-Path $pluginDir 'ReActionAI.Modules.RevitChatGPT.dll'
Copy-Item $dll $targetDll -Force
Write-Host "Copied DLL -> $targetDll"

# Generate single-Application addin
$addinPath = Join-Path $pluginDir 'ReActionAI.Modules.RevitChatGPT.addin'
$addinXml = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>ReActionAI.App</Name>
    <Assembly>$targetDll</Assembly>
    <AddInId>{6E12C980-A9AF-4A47-B61C-4DB71A2C31C1}</AddInId>
    <FullClassName>ReActionAI.Modules.RevitChatGPT.App</FullClassName>
    <VendorId>RAAK</VendorId>
    <VendorDescription>ReActionAI</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
$addinXml | Out-File $addinPath -Encoding UTF8 -Force
Write-Host "Generated .addin -> $addinPath"

# Clear AddInCache
$cache = Join-Path $env:LOCALAPPDATA 'Autodesk\Revit\Addins\2024\AddInCache'
if (Test-Path $cache) { Remove-Item $cache -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "Cleared AddInCache" }

Write-Host "`n== Deployed files =="
Get-ChildItem $pluginDir | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize
Write-Host "`nDone. Launch Revit 2024."
